clear all
clc

% Nombre del archivo codificado
% Secuencia Barker Binaria con codificación UTF-8
archivo = 'secuencia.txt';

% Leer el archivo txt 
file = fileread(archivo);


% Convertir la secuencia de caracteres en un vector de bits numéricos
source = double(file == '1');
barker = [1 1 1 0 0 0 1 0 0 1 0];
source = [zeros(1,20) barker source];

% Parámetros del sistema de comunicaciones con modulación FSK
frec = 3.00e5;               % Frecuencia de la señal portadora
rata = 6.00e3;               % Rata en bps 
pe = 3e-2;                   % Probxabilidad de error
dmin = 5.00e4;               % Distancia mínima en metros
dmax = 5.00e6;               % Distancia máxima en metros
gt = 5;                      % Ganancia Gt en dBi
gr = 5;                      % Ganancia Gr en dBi
temp = 500;                  % Temperatura equivalente en Kelvin                  

k = physconst('Boltzmann');             % Constante de Boltzmann (eV/K)
C = physconst('LightSpeed');            % Velocidad de la luz en el vacío (m/s)

% Delay máximo y mínimo en segundos (distancia/C)
demin = dmin/C;           
demax = dmax/C;  

% Variables del Canal 
Tb = 1/rata;                            % Tiempo de bit
fsep = rata/4;                          % Separación de la frecuencia central 

distance = dmax;                        % Distancia máxima

trig = 0;                               % Trigger o umbral
trash =  zeros(1,20);                   % Basura   

lambda = C/frec;                        % Longitud de onda de la señal portadora
cdelay = distance/C;                    % Retraso en el canal


% Atenuación del canal en dB
atdb = 22 + 20*log10(distance/lambda) - gr - gt; 

% Atenuación del canal en Watts
atw = 10^(atdb/10);     

% Atenuación del canal en Voltios
atv = 10^(atdb/20);  

% Cálculos de características del sistema de comunicaciones
x = sqrt(2)*erfcinv(pe);                 % Función inversa de la probabilidad de error para estimar la energía del ruido
n0 = temp * k;                           % Energía térmica del ruido ETA
inE = n0 * x^2;                          % Energía de entrada al sistema
outE = inE * atw;                        % Energía de salida del sistema

% Para modulación FSK 
amp = sqrt((outE * rata * 2)/0.9);       % Amplitud de la señal modulada
bwmin = rata / 2;                        % Ancho de banda mínimo
bwnoise = rata;                      % Ancho de banda del ruido
             
k = 1;
Etrans = 0.9 * (amp^2) / (2 * rata);     % Energía transmitida
Erec = Etrans / atw;                     % Energía recibida

eta = k * Erec/(x^2);
pnoise = 2 * eta * bwmin;             % Potencia del ruido

% Sincronismo de portadora con lazo PLL tipo 2
cap = 1e-6;                              % Capacitancia 
Ts = 0.1 * Tb;                           % Tiempo de establecimiento del lazo
zita = 0.5;                              % Factor de amortiguamiento
kp = 0.5;                                % Ganancia proporcional
kv = 2 * pi * 1E4;                       % Ganancia de velocidad
wn = 4.5/ Ts;                            % Frecuencia natural del lazo

% Resistencias para filtro del lazo
R1 = kp * kv / (wn^2 * cap);
R2 = 2 * zita / (wn * cap);

Klazo = R2 * kv * kp/R1;                     % Ganancia del lazo
bwl = wn*(zita+1/(4*zita));              % Ancho de banda del lazo

% Sincronismo de Reloj utilizando la compuerta Early_Late
b = 0.8;
kv2 = rata^2/10;


% Diseño del filtro Butternorth de primer orden
[bb,aa] = butter(1,0.85*frec/(frec*2/2));

